main()
{
	int	i, j;

	for (i = 0; i <8000;)
	{
		for (j = 0; j < 10; j++, i++)
			printf("%d", j);
	}
}
